﻿const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");

function loadEnv() {
    const envPaths = ['.env.local', '.env'];
    for (const ep of envPaths) {
        const fullPath = path.join(__dirname, ep);
        if (fs.existsSync(fullPath)) {
            const content = fs.readFileSync(fullPath, 'utf8');
            content.split('\n').forEach(line => {
                const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
                if (match) {
                    const key = match[1];
                    let value = match[2] || '';
                    if (value.startsWith('"') && value.endsWith('"')) {
                        value = value.slice(1, -1);
                    }
                    process.env[key] = value;
                }
            });
        }
    }
}

loadEnv();

const productSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    currency: { type: String, required: true, default: "USD" },
    category: { type: String, required: true },
    imageUrl: { type: String, required: true },
    stock: { type: Number, required: true, default: 0, min: 0 },
    isActive: { type: Boolean, default: true },
    productType: { type: String, default: 'physical' },
    rating: { type: Number, default: 4.5 },
    numReviews: { type: Number, default: 12 },
}, { timestamps: true });

const Product = mongoose.models.Product || mongoose.model("Product", productSchema);

const sampleProducts = [
    {
        title: "Sony WH-1000XM5 Wireless Headphones",
        description: "Industry-leading noise cancellation. Features two processors controlling 8 microphones for unprecedented noise cancellation. With Auto NC Optimizer, noise canceling is automatically optimized based on your wearing conditions and environment.",
        price: 348.00,
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?q=80&w=800&auto=format&fit=crop",
        stock: 50,
        rating: 4.8,
        numReviews: 320
    },
    {
        title: "MacBook Pro M2 14-inch",
        description: "Supercharged by M2 Pro or M2 Max, MacBook Pro takes its power and efficiency further than ever. It delivers exceptional performance whether it's plugged in or not, and now has even longer battery life.",
        price: 1999.00,
        category: "Computers",
        imageUrl: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?q=80&w=800&auto=format&fit=crop",
        stock: 15,
        rating: 4.9,
        numReviews: 125
    },
    {
        title: "Nike Air Force 1 '07",
        description: "The radiance lives on in the Nike Air Force 1 '07, the b-ball icon that puts a fresh spin on what you know best: crisp leather, bold colors and the perfect amount of flash to make you shine.",
        price: 110.00,
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=800&auto=format&fit=crop",
        stock: 120,
        rating: 4.6,
        numReviews: 890
    },
    {
        title: "Apple Watch Series 8",
        description: "Your essential companion is now even more powerful. Introducing temperature sensing for deeper insights into women's health. Crash Detection to get help in an emergency. Sleep stages to better understand your sleep.",
        price: 399.00,
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?q=80&w=800&auto=format&fit=crop",
        stock: 45,
        rating: 4.7,
        numReviews: 450
    },
    {
        title: "Samsung Galaxy S23 Ultra",
        description: "Capture the night with crystal clear, bright pics and videos, no matter the lighting with Nightography. The highest phone camera resolution lets you capture incredible detail with 200MP.",
        price: 1199.99,
        category: "Smartphones",
        imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?q=80&w=800&auto=format&fit=crop",
        stock: 25,
        rating: 4.8,
        numReviews: 310
    },
    {
        title: "Dyson V15 Detect Cordless Vacuum",
        description: "The most powerful, intelligent cordless vacuum. A laser makes invisible dust visible on hard floors. A piezo sensor continuously sizes and counts dust particles.",
        price: 749.99,
        category: "Home",
        imageUrl: "https://images.unsplash.com/photo-1558317374-067fb5f30001?q=80&w=800&auto=format&fit=crop",
        stock: 30,
        rating: 4.5,
        numReviews: 180
    },
    {
        title: "Sony PlayStation 5 Console",
        description: "Experience lightning-fast loading with an ultra-high speed SSD, deeper immersion with support for haptic feedback, adaptive triggers, and 3D Audio, and an all-new generation of incredible PlayStation games.",
        price: 499.99,
        category: "Gaming",
        imageUrl: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?q=80&w=800&auto=format&fit=crop",
        stock: 10,
        rating: 4.9,
        numReviews: 2100
    },
    {
        title: "Canon EOS R6 Mark II",
        description: "A versatile hybrid camera for both photo and video creators. Features a 24.2 MP full-frame sensor, advanced Dual Pixel CMOS AF II, and incredibly fast continuous shooting.",
        price: 2499.00,
        category: "Cameras",
        imageUrl: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=800&auto=format&fit=crop",
        stock: 5,
        rating: 4.8,
        numReviews: 75
    },
    {
        title: "The North Face Nuptse Jacket",
        description: "A classic, durable puffer jacket designed to provide incredible warmth in cold weather. Features responsibly sourced 700-fill down insulation and a water-repellent finish.",
        price: 280.00,
        category: "Fashion",
        imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=800&auto=format&fit=crop",
        stock: 40,
        rating: 4.7,
        numReviews: 220
    },
    {
        title: "Nespresso VertuoPlus Coffee Machine",
        description: "Brews 4 different cup sizes at the touch of a button. Features Centrifusion technology for the perfect crema every time. Includes a welcome set of Nespresso capsules.",
        price: 159.00,
        category: "Home",
        imageUrl: "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?q=80&w=800&auto=format&fit=crop",
        stock: 65,
        rating: 4.6,
        numReviews: 540
    },
    {
        title: "Ray-Ban Classic Wayfarer Sunglasses",
        description: "The most recognizable style in the history of sunglasses. Since its initial design in 1952, Wayfarer Classics gained popularity among celebrities, musicians, and artists.",
        price: 163.00,
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=800&auto=format&fit=crop",
        stock: 150,
        rating: 4.8,
        numReviews: 1200
    },
    {
        title: "Fitbit Charge 5 Fitness Tracker",
        description: "Advanced health and fitness tracker with built-in GPS, stress management tools, sleep tracking, and a vibrant color touchscreen. Includes a 6-month Premium membership.",
        price: 149.95,
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b0?q=80&w=800&auto=format&fit=crop",
        stock: 80,
        rating: 4.4,
        numReviews: 330
    },
    {
        title: "KitchenAid Artisan Stand Mixer",
        description: "The iconic stand mixer with a 5-quart capacity, powerful motor, and 10 speed settings. Perfect for everything from mixing batter to kneading dough. Includes flat beater, dough hook, and wire whip.",
        price: 449.99,
        category: "Home",
        imageUrl: "https://images.unsplash.com/photo-1593005856754-077a94ddbe6d?q=80&w=800&auto=format&fit=crop",
        stock: 22,
        rating: 4.9,
        numReviews: 890
    },
    {
        title: "Bose SoundLink Revolve+ II Bluetooth Speaker",
        description: "Engineered to deliver true 360-degree sound for consistent, uniform coverage. Place it in the center of the room to give everyone the same experience. Water and dust resistant.",
        price: 329.00,
        category: "Electronics",
        imageUrl: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=800&auto=format&fit=crop",
        stock: 55,
        rating: 4.7,
        numReviews: 410
    },
    {
        title: "Yeti Rambler 20 oz Tumbler",
        description: "Any tumbler that's coming along for the ride needs to be tough enough to keep up. Made from durable stainless steel with double-wall vacuum insulation to protect your hot or cold beverage at all costs.",
        price: 35.00,
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1590731057497-6a12b8ef989f?q=80&w=800&auto=format&fit=crop",
        stock: 200,
        rating: 4.9,
        numReviews: 3400
    },
    {
        title: "DJI Mini 3 Pro Drone",
        description: "Weighing less than 249g, it's incredibly portable and doesn't require registration in most countries. Features tri-directional obstacle sensing and 4K HDR video capabilities.",
        price: 759.00,
        category: "Cameras",
        imageUrl: "https://images.unsplash.com/photo-1579829366248-204fe8413f31?q=80&w=800&auto=format&fit=crop",
        stock: 18,
        rating: 4.8,
        numReviews: 275
    },
    {
        title: "Oculus Quest 2 Advanced VR Headset",
        description: "Experience total immersion with 3D positional audio, hand tracking and haptic feedback. Enjoy an ever-expanding library of over 250 titles across gaming, fitness, social and more.",
        price: 299.00,
        category: "Gaming",
        imageUrl: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?q=80&w=800&auto=format&fit=crop",
        stock: 45,
        rating: 4.7,
        numReviews: 1500
    },
    {
        title: "Casio G-Shock Classic Watch",
        description: "Shock resistant, 200-meter water resistant, auto LED light with afterglow, world time, 4 daily alarms, stopwatch, and countdown timer. The ultimate tough watch.",
        price: 99.00,
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=800&auto=format&fit=crop",
        stock: 75,
        rating: 4.6,
        numReviews: 680
    },
    {
        title: "Logitech MX Master 3S Wireless Mouse",
        description: "Experience ultimate comfort and performance. Features an 8000 DPI track-on-glass sensor, quiet clicks, and MagSpeed electromagnetic scrolling. Works across multiple computers.",
        price: 99.99,
        category: "Computers",
        imageUrl: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?q=80&w=800&auto=format&fit=crop",
        stock: 90,
        rating: 4.8,
        numReviews: 820
    },
    {
        title: "Hydro Flask Wide Mouth Water Bottle",
        description: "Keep cold drinks icy cold and hot drinks piping hot for hours. Made with pro-grade stainless steel and featuring TempShield double-wall vacuum insulation.",
        price: 44.95,
        category: "Accessories",
        imageUrl: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?q=80&w=800&auto=format&fit=crop",
        stock: 120,
        rating: 4.8,
        numReviews: 2100
    }
];

const seedDB = async () => {
    try {
        const uri = process.env.MONGODB_URI;
        if (!uri) {
            console.error("❌ MONGODB_URI is not defined in .env or .env.local file");
            process.exit(1);
        }

        console.log("Connecting to MongoDB...");
        await mongoose.connect(uri);
        console.log("✅ Connected to MongoDB");

        console.log("Deleting old products...");
        await Product.deleteMany({});
        
        console.log("Inserting 20 sample products...");
        await Product.insertMany(sampleProducts);
        
        console.log("✅ Database seeded successfully with premium realistic products!");
        
        process.exit(0);
    } catch (error) {
        console.error("❌ Error seeding database:", error);
        process.exit(1);
    }
};

seedDB();
